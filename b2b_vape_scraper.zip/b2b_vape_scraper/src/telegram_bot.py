import asyncio
from pathlib import Path
from loguru import logger
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup

class TelegramNotifier:
    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id
        self.bot = Bot(token=token)

    async def send_message(self, text: str):
        try:
            await self.bot.send_message(chat_id=self.chat_id, text=text, parse_mode="HTML")
            logger.info("Успешно отправлено текстовое уведомление в Telegram")
        except Exception as e:
            logger.error(f"Ошибка отправки текста в Telegram: {e}")

    async def send_document(self, file_path: str, caption: str = ""):
        try:
            path = Path(file_path)
            if not path.exists():
                logger.error(f"Файл для отправки не найден: {file_path}")
                return
            
            with open(path, "rb") as doc:
                await self.bot.send_document(
                    chat_id=self.chat_id,
                    document=doc,
                    caption=caption,
                    parse_mode="HTML"
                )
            logger.info(f"Файл {path.name} успешно отправлен в Telegram")
        except Exception as e:
            logger.error(f"Ошибка отправки файла в Telegram: {e}")

def get_main_keyboard():
    keyboard = [
        [InlineKeyboardButton("🔥 Вся Россия (Сводный отчет)", callback_data="full_russia")],
        [InlineKeyboardButton("📍 Выбрать город / Топ", callback_data="select_city")],
        [InlineKeyboardButton("📊 Запросить отчет в группу", callback_data="send_report")]
    ]
    return InlineKeyboardMarkup(keyboard)
