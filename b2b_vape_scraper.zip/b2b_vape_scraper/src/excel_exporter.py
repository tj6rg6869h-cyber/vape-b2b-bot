import pandas as pd
from pathlib import Path
from typing import List
from loguru import logger
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from config.settings import PRIORITY_CITIES
from src.models import VapeShopLead

def save_leads_to_excel(leads: List[VapeShopLead], filename: str = "vape_leads_all_cities.xlsx") -> str:
    data = []
    for lead in leads:
        is_priority = lead.city in PRIORITY_CITIES
        data.append({
            "Приоритет": "🔥 ТОП" if is_priority else "Обычный",
            "Название": lead.name,
            "Город": lead.city,
            "Адрес": lead.address,
            "Телефоны": ", ".join(lead.phones),
            "Мобильный (Менеджер)": "Да" if lead.has_mobile_phone else "Нет",
            "Telegram": lead.telegram or "",
            "WhatsApp": lead.whatsapp or "",
            "_is_priority": is_priority
        })
    
    # Сортируем: сначала приоритетные города, потом остальные по алфавиту
    data.sort(key=lambda x: (not x["_is_priority"], x["Город"]))
    
    df = pd.DataFrame(data)
    export_df = df.drop(columns=["_is_priority"])
    filepath = Path(filename)
    
    with pd.ExcelWriter(filepath, engine="openpyxl") as writer:
        export_df.to_excel(writer, index=False, sheet_name="База B2B РФ")
        worksheet = writer.sheets["База B2B РФ"]
        
        # Стили оформления
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        header_font = Font(name="Calibri", size=11, color="FFFFFF", bold=True)
        
        priority_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid") # Нежно-желтая заливка для ТОП
        default_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
        
        thin_border = Border(
            left=Side(style='thin', color='D9D9D9'),
            right=Side(style='thin', color='D9D9D9'),
            top=Side(style='thin', color='D9D9D9'),
            bottom=Side(style='thin', color='D9D9D9')
        )
        
        worksheet.freeze_panes = "A2"
        
        # Оформление шапки
        for col_idx, col in enumerate(worksheet.columns, 1):
            col_letter = get_column_letter(col_idx)
            worksheet.column_dimensions[col_letter].width = 24
            cell = worksheet.cell(row=1, column=col_idx)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = thin_border
            
        worksheet.row_dimensions[1].height = 28

        # Оформление строк данных
        for row_idx, row in enumerate(worksheet.iter_rows(min_row=2), start=2):
            is_priority = data[row_idx - 2]["_is_priority"]
            row_fill = priority_fill if is_priority else default_fill
            
            worksheet.row_dimensions[row_idx].height = 22
            
            for cell in row:
                cell.fill = row_fill
                cell.border = thin_border
                cell.alignment = Alignment(vertical="center", wrap_text=True)
                # Выравниваем колонку приоритета по центру
                if cell.column == 1:
                    cell.alignment = Alignment(horizontal="center", vertical="center")

    logger.success(f"Элитная таблица успешно сохранена: {filepath.absolute()}")
    return str(filepath)
