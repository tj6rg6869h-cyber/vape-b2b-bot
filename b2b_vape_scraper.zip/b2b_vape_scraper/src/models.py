import re
from typing import Optional, List
from pydantic import BaseModel, Field, computed_field, field_validator

class VapeShopLead(BaseModel):
    name: str
    city: str
    address: str
    phones: List[str]
    telegram: Optional[str] = None
    whatsapp: Optional[str] = None

    @field_validator("phones")
    @classmethod
    def clean_phones(cls, v: List[str]) -> List[str]:
        cleaned = []
        for p in v:
            digits = re.sub(r"\D", "", p)
            if digits.startswith("8") and len(digits) == 11:
                digits = "7" + digits[1:]
            if len(digits) == 11:
                cleaned.append(f"+{digits}")
        return list(set(cleaned))

    @computed_field
    @property
    def has_mobile_phone(self) -> bool:
        return any(p.startswith("+79") for p in self.phones)
